import React from "react";

export default class HomePage extends React.Component {
    render() {
        return (
            <div className="">
                <section className="p-5 abeezee flex flex-wrap space-x-3">
                    <div className="p-8 px-12 flex flex-wrap justify-center items-center rounded-md text-white rounded-md text-white w-3/12 bg-gradient-to-tl from-first-500 to-pink-700">

                    </div>
                </section>
            </div>
        );
    }
}