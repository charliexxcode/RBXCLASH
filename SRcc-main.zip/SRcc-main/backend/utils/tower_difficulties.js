const TowerGameDifficulties = {
    0: "Easy",
    1: "Normal",
    2: "Hard",

    get easy() {
        return 0
    },

    get normal() {
        return 1
    },

    get hard() {
        return 2
    },
}

module.exports = TowerGameDifficulties